import streamlit as st
from openai import AzureOpenAI

def test_connection(endpoint, api_key, deployment, api_version):
    try:
        client = AzureOpenAI(
            api_version=api_version,
            azure_endpoint=endpoint,
            api_key=api_key,
        )
        client.completions.create(
            prompt="prova",
            max_tokens=5,

            temperature=0.1,
            top_p=1.0,
            model=deployment,
        )
        return True, None
    except Exception as e:
        return False, str(e)
    

DEFAULT_DEPLOYMENT = "gpt-35-turbo-instruct"
DEFAULT_API_VERSION = "2024-12-01-preview"
DEFAULT_ENDPOINT = "https://tizia-memkxxzm-swedencentral.cognitiveservices.azure.com/"



def get_client(endpoint, api_key, api_version):
    return AzureOpenAI(
        api_version=api_version,
        azure_endpoint=endpoint,
        api_key=api_key,
    )

def get_completion_stream(client, prompt, deployment):
    response = client.completions.create(
        prompt=prompt,
        max_tokens=2000,
        temperature=1.0,
        top_p=1.0,
        model=deployment,
        stream=True
    )
    full_text = ""
    for chunk in response:
        if hasattr(chunk, "choices") and chunk.choices and hasattr(chunk.choices[0], "text"):
            full_text += chunk.choices[0].text
            yield full_text

def page_login():
    st.title("Login Azure OpenAI")
    endpoint_input = st.text_input("Endpoint Azure OpenAI", value=DEFAULT_ENDPOINT, key="endpoint_input")
    deployment_input = st.text_input("Deployment", value=DEFAULT_DEPLOYMENT, key="deployment_input")
    api_version_input = st.text_input("API Version", value=DEFAULT_API_VERSION, key="api_version_input")
    api_key_input = st.text_input("API Key", value="", type="password", key="api_key_input")
    test_btn = st.button("Verifica e accedi")
    if test_btn:
        ok, error = test_connection(endpoint_input, api_key_input, deployment_input, api_version_input)
        if ok:
            st.session_state.endpoint = endpoint_input
            st.session_state.api_key = api_key_input
            st.session_state.deployment = deployment_input
            st.session_state.api_version = api_version_input
            st.session_state.logged_in = True
            st.session_state.error_msg = None
            st.session_state.page = "Chat"
            st.rerun()
        else:
            st.session_state.error_msg = error
            st.session_state.logged_in = False
            st.session_state.page = "Error"
            st.rerun()

def page_error():
    st.title("Errore di connessione")
    st.error(f"Connessione fallita: {st.session_state.get('error_msg','')}\n\nVerifica che endpoint, API key e deployment siano corretti.")
    if st.button("Torna al login"):
        st.session_state.page = "Login"
        st.rerun()

def page_chat():
    st.title("ChatGPT Fasullo")
    client = get_client(st.session_state.endpoint, st.session_state.api_key, st.session_state.api_version)
    deployment = st.session_state.deployment
    if 'chat_history' not in st.session_state:
        st.session_state.chat_history = []
    for msg in st.session_state.chat_history:
        if msg["role"] == "user":
            with st.chat_message("user"):
                st.markdown(msg["content"])
        else:
            with st.chat_message("assistant"):
                st.markdown(msg["content"])
    user_input = st.chat_input("Scrivi il tuo messaggio...")
    if user_input:
        st.session_state.chat_history.append({"role": "user", "content": user_input})
        with st.chat_message("user"):
            st.markdown(user_input)
        with st.chat_message("assistant"):
            response_placeholder = st.empty()
            full_response = ""
            try:
                for partial in get_completion_stream(client, user_input, deployment):
                    full_response = partial
                    response_placeholder.markdown(full_response)
                st.session_state.chat_history.append({"role": "assistant", "content": full_response})
            except Exception as e:
                error_msg = f"Errore: {e}"
                response_placeholder.markdown(error_msg)
                st.session_state.chat_history.append({"role": "assistant", "content": error_msg})

def page_logout():
    st.title("Logout")
    if st.button("Conferma logout"):
        for k in ["endpoint", "api_key", "deployment", "api_version", "logged_in", "chat_history", "error_msg"]:
            if k in st.session_state:
                del st.session_state[k]
        st.session_state.page = "Login"
        st.rerun()
    st.write("Sei sicuro di voler uscire?")