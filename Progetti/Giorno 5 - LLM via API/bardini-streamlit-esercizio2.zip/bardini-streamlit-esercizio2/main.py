import streamlit as st
from openai import AzureOpenAI
from utils import page_login, page_chat, page_error, page_logout


def main():
    st.set_page_config(page_title="ChatGPT Fasullo")
    if "page" not in st.session_state:
        st.session_state.page = "Login"
    if "logged_in" not in st.session_state:
        st.session_state.logged_in = False

    if not st.session_state.logged_in:
        st.session_state.page = "Login"
        page_login()
    else:
        if st.session_state.page == "Chat":
            allowed_pages = ["Chat", "Logout"]
            page = st.sidebar.radio("Naviga tra le pagine:", allowed_pages, index=allowed_pages.index(st.session_state.page))
            st.session_state.page = page
            if st.session_state.page == "Chat":
                page_chat()
            elif st.session_state.page == "Logout":
                page_logout()
        elif st.session_state.page == "Logout":
            page_logout()
        elif st.session_state.page == "Error":
            page_error()




main()



