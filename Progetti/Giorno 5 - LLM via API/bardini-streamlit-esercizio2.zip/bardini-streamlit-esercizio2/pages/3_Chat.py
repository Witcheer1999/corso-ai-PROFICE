import streamlit as st
from utils import get_client, get_completion_stream

st.title("ChatGPT Fasullo")
if not all(k in st.session_state for k in ["endpoint", "api_key", "api_version", "deployment"]):
    st.warning("Devi prima accedere dalla pagina Login.")
    st.stop()
client = get_client(st.session_state.endpoint, st.session_state.api_key, st.session_state.api_version)
deployment = st.session_state.deployment
if 'chat_history' not in st.session_state:
    st.session_state.chat_history = []
if 'input_value' not in st.session_state:
    st.session_state.input_value = ""
for msg in st.session_state.chat_history:
    if msg["role"] == "user":
        with st.chat_message("user"):
            st.markdown(msg["content"])
    else:
        with st.chat_message("assistant"):
            st.markdown(msg["content"])
user_input = st.chat_input("Scrivi il tuo messaggio...")
if user_input:
    st.session_state.chat_history.append({"role": "user", "content": user_input})
    with st.chat_message("user"):
        st.markdown(user_input)
    with st.chat_message("assistant"):
        response_placeholder = st.empty()
        full_response = ""
        try:
            for partial in get_completion_stream(client, user_input, deployment):
                full_response = partial
                response_placeholder.markdown(full_response)
            st.session_state.chat_history.append({"role": "assistant", "content": full_response})
        except Exception as e:
            error_msg = f"Errore: {e}"
            response_placeholder.markdown(error_msg)
            st.session_state.chat_history.append({"role": "assistant", "content": error_msg})
