import streamlit as st

st.title("Errore di connessione")
error_msg = st.session_state.get('error_msg','')
st.error(f"Connessione fallita: {error_msg}\n\nVerifica che endpoint, API key e deployment siano corretti.")
if st.button("Torna indietro"):
    st.switch_page("pages/1_Login.py")
