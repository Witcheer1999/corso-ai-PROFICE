import streamlit as st
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(__file__)))
from utils import test_connection, DEFAULT_ENDPOINT, DEFAULT_DEPLOYMENT, DEFAULT_API_VERSION

st.title("Inserisci credenziali Azure OpenAI")
endpoint_input = st.text_input("Endpoint Azure OpenAI", value=DEFAULT_ENDPOINT, key="endpoint_input")
deployment_input = st.text_input("Deployment", value=DEFAULT_DEPLOYMENT, key="deployment_input")
api_version_input = st.text_input("API Version", value=DEFAULT_API_VERSION, key="api_version_input")
api_key_input = st.text_input("API Key", value="", type="password", key="api_key_input")
test_btn = st.button("Verifica e accedi")
if test_btn:
    ok, error = test_connection(endpoint_input, api_key_input, deployment_input, api_version_input)
    if ok:
        st.session_state.endpoint = endpoint_input
        st.session_state.api_key = api_key_input
        st.session_state.deployment = deployment_input
        st.session_state.api_version = api_version_input
        st.success("Connessione riuscita! Puoi andare alla pagina Chat.")
    else:
        st.session_state.error_msg = error
        st.error(f"Connessione fallita: {error}")
